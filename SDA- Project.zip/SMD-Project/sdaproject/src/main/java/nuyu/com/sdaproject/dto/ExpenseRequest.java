package nuyu.com.sdaproject.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import nuyu.com.sdaproject.model.Expense;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ExpenseRequest {

    @NotBlank(message = "Project code is required")
    private String projectCode;

    @NotNull(message = "Category is required")
    private Expense.Category category;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Amount must be greater than 0")
    private BigDecimal amount;

    @NotNull(message = "Expense date is required")
    @PastOrPresent(message = "Expense date cannot be in the future")
    private LocalDate expenseDate;

    @NotBlank(message = "Vendor is required")
    private String vendor;
}
