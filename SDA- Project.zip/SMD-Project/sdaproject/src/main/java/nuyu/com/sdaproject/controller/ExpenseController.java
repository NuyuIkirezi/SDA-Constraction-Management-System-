package nuyu.com.sdaproject.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import nuyu.com.sdaproject.dto.ApiResponse;
import nuyu.com.sdaproject.dto.ExpenseRequest;
import nuyu.com.sdaproject.dto.ExpenseResponse;
import nuyu.com.sdaproject.model.Expense;
import nuyu.com.sdaproject.service.ExpenseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/expenses")
@Tag(name = "Expenses", description = "Project expense tracking and management")
@SecurityRequirement(name = "bearerAuth")
public class ExpenseController {

    private final ExpenseService expenseService;

    public ExpenseController(ExpenseService expenseService) {
        this.expenseService = expenseService;
    }

    @GetMapping
    @Operation(summary = "Get all expenses", description = "Optionally filter by project code or category.")
    public ResponseEntity<ApiResponse<List<ExpenseResponse>>> getAllExpenses(
            @Parameter(description = "Filter by project code e.g. PRJ-2024-001")
            @RequestParam(required = false) String projectCode,
            @Parameter(description = "Filter by category: MATERIALS, LABOR, EQUIPMENT, TRANSPORT, OTHER")
            @RequestParam(required = false) Expense.Category category) {

        List<ExpenseResponse> expenses;
        if (projectCode != null && !projectCode.isBlank()) {
            expenses = expenseService.getByProject(projectCode);
        } else if (category != null) {
            expenses = expenseService.getByCategory(category);
        } else {
            expenses = expenseService.getAllExpenses();
        }
        return ResponseEntity.ok(ApiResponse.success("Expenses retrieved", expenses));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get expense by ID")
    public ResponseEntity<ApiResponse<ExpenseResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Expense retrieved", expenseService.getById(id)));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ACCOUNTANT')")
    @Operation(summary = "Record a new expense", description = "Admin and Accountant only.")
    public ResponseEntity<ApiResponse<ExpenseResponse>> createExpense(@Valid @RequestBody ExpenseRequest request) {
        ExpenseResponse created = expenseService.createExpense(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Expense recorded successfully", created));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ACCOUNTANT')")
    @Operation(summary = "Update an expense", description = "Admin and Accountant only.")
    public ResponseEntity<ApiResponse<ExpenseResponse>> updateExpense(
            @PathVariable Long id, @Valid @RequestBody ExpenseRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Expense updated successfully",
                expenseService.updateExpense(id, request)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ACCOUNTANT')")
    @Operation(summary = "Delete an expense", description = "Admin and Accountant only.")
    public ResponseEntity<ApiResponse<Void>> deleteExpense(@PathVariable Long id) {
        expenseService.deleteExpense(id);
        return ResponseEntity.ok(ApiResponse.success("Expense deleted successfully", null));
    }
}
