package nuyu.com.sdaproject.service;

import nuyu.com.sdaproject.dto.ExpenseRequest;
import nuyu.com.sdaproject.dto.ExpenseResponse;
import nuyu.com.sdaproject.exception.ResourceNotFoundException;
import nuyu.com.sdaproject.model.Expense;
import nuyu.com.sdaproject.model.Project;
import nuyu.com.sdaproject.repository.ExpenseRepository;
import nuyu.com.sdaproject.repository.ProjectRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
@Transactional
public class ExpenseService {

    private final ExpenseRepository expenseRepository;
    private final ProjectRepository projectRepository;

    public ExpenseService(ExpenseRepository expenseRepository, ProjectRepository projectRepository) {
        this.expenseRepository = expenseRepository;
        this.projectRepository = projectRepository;
    }

    public List<ExpenseResponse> getAllExpenses() {
        return expenseRepository.findAll().stream().map(this::toResponse).toList();
    }

    public ExpenseResponse getById(Long id) {
        Expense expense = expenseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Expense not found with id: " + id));
        return toResponse(expense);
    }

    public List<ExpenseResponse> getByProject(String projectCode) {
        return expenseRepository.findByProjectProjectCode(projectCode)
                .stream().map(this::toResponse).toList();
    }

    public List<ExpenseResponse> getByCategory(Expense.Category category) {
        return expenseRepository.findByCategory(category).stream().map(this::toResponse).toList();
    }

    public ExpenseResponse createExpense(ExpenseRequest request) {
        Project project = projectRepository.findByProjectCode(request.getProjectCode())
                .orElseThrow(() -> new ResourceNotFoundException("Project not found: " + request.getProjectCode()));

        String code = generateExpenseCode();
        Expense expense = Expense.builder()
                .expenseCode(code)
                .project(project)
                .category(request.getCategory())
                .amount(request.getAmount())
                .expenseDate(request.getExpenseDate())
                .vendor(request.getVendor())
                .build();
        return toResponse(expenseRepository.save(expense));
    }

    public ExpenseResponse updateExpense(Long id, ExpenseRequest request) {
        Expense expense = expenseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Expense not found with id: " + id));

        Project project = projectRepository.findByProjectCode(request.getProjectCode())
                .orElseThrow(() -> new ResourceNotFoundException("Project not found: " + request.getProjectCode()));

        expense.setProject(project);
        expense.setCategory(request.getCategory());
        expense.setAmount(request.getAmount());
        expense.setExpenseDate(request.getExpenseDate());
        expense.setVendor(request.getVendor());
        return toResponse(expenseRepository.save(expense));
    }

    public void deleteExpense(Long id) {
        if (!expenseRepository.existsById(id)) {
            throw new ResourceNotFoundException("Expense not found with id: " + id);
        }
        expenseRepository.deleteById(id);
    }

    private String generateExpenseCode() {
        long count = expenseRepository.count() + 1;
        return String.format("EXP-%03d", count);
    }

    private ExpenseResponse toResponse(Expense expense) {
        return ExpenseResponse.builder()
                .id(expense.getId())
                .expenseCode(expense.getExpenseCode())
                .projectCode(expense.getProject().getProjectCode())
                .projectName(expense.getProject().getName())
                .category(expense.getCategory())
                .amount(expense.getAmount())
                .expenseDate(expense.getExpenseDate())
                .vendor(expense.getVendor())
                .createdAt(expense.getCreatedAt())
                .build();
    }

}
