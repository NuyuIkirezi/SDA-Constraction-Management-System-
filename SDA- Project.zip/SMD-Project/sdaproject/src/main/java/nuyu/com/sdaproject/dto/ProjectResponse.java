package nuyu.com.sdaproject.dto;

import lombok.Builder;
import lombok.Data;
import nuyu.com.sdaproject.model.Project;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data @Builder
public class ProjectResponse {
    private Long id;
    private String projectCode;
    private String name;
    private String location;
    private String manager;
    private Project.Status status;
    private BigDecimal budget;
    private Integer progress;
    private BigDecimal totalExpenses;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
