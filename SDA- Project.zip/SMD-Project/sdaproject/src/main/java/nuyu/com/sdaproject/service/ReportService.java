package nuyu.com.sdaproject.service;

import nuyu.com.sdaproject.dto.DashboardStats;
import nuyu.com.sdaproject.model.Project;
import nuyu.com.sdaproject.repository.ExpenseRepository;
import nuyu.com.sdaproject.repository.ProjectRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional(readOnly = true)
public class ReportService {

    private final ProjectRepository projectRepository;
    private final ExpenseRepository expenseRepository;

    public ReportService(ProjectRepository projectRepository, ExpenseRepository expenseRepository) {
        this.projectRepository = projectRepository;
        this.expenseRepository = expenseRepository;
    }

    public DashboardStats getDashboardStats() {
        long total = projectRepository.count();
        long active = projectRepository.countByStatus(Project.Status.ACTIVE);
        long pending = projectRepository.countByStatus(Project.Status.PENDING);
        long completed = projectRepository.countByStatus(Project.Status.COMPLETED);

        BigDecimal totalBudget = projectRepository.sumTotalBudget();
        if (totalBudget == null) totalBudget = BigDecimal.ZERO;

        BigDecimal totalExpenses = expenseRepository.sumTotalExpenses();
        if (totalExpenses == null) totalExpenses = BigDecimal.ZERO;

        BigDecimal remaining = totalBudget.subtract(totalExpenses);

        double utilization = totalBudget.compareTo(BigDecimal.ZERO) > 0
                ? totalExpenses.divide(totalBudget, 4, RoundingMode.HALF_UP)
                        .multiply(BigDecimal.valueOf(100)).doubleValue()
                : 0.0;

        Double avgProgress = projectRepository.averageProgress();

        // Expenses grouped by category
        List<Object[]> categoryData = expenseRepository.sumExpensesByCategory();
        Map<String, BigDecimal> expensesByCategory = new HashMap<>();
        categoryData.forEach(row -> expensesByCategory.put(row[0].toString(), (BigDecimal) row[1]));

        return DashboardStats.builder()
                .totalProjects(total)
                .activeProjects(active)
                .pendingProjects(pending)
                .completedProjects(completed)
                .totalBudget(totalBudget)
                .totalExpenses(totalExpenses)
                .remainingBudget(remaining)
                .budgetUtilizationPercent(utilization)
                .averageProgress(avgProgress != null ? avgProgress : 0.0)
                .expensesByCategory(expensesByCategory)
                .build();
    }
}
