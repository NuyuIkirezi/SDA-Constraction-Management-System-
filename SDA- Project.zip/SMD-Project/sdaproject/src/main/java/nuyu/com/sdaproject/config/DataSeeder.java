package nuyu.com.sdaproject.config;

import jakarta.annotation.PostConstruct;
import nuyu.com.sdaproject.model.Expense;
import nuyu.com.sdaproject.model.Project;
import nuyu.com.sdaproject.model.User;
import nuyu.com.sdaproject.repository.ExpenseRepository;
import nuyu.com.sdaproject.repository.ProjectRepository;
import nuyu.com.sdaproject.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * DataSeeder — runs once on startup and populates the database
 * with users, projects and expenses in the correct dependency order.
 * Safe to re-run: each block checks count before inserting.
 */
@Component
public class DataSeeder {

    private final UserRepository    userRepository;
    private final ProjectRepository projectRepository;
    private final ExpenseRepository expenseRepository;
    private final PasswordEncoder   passwordEncoder;

    public DataSeeder(UserRepository userRepository,
                      ProjectRepository projectRepository,
                      ExpenseRepository expenseRepository,
                      PasswordEncoder passwordEncoder) {
        this.userRepository    = userRepository;
        this.projectRepository = projectRepository;
        this.expenseRepository = expenseRepository;
        this.passwordEncoder   = passwordEncoder;
    }

    @PostConstruct
    @Transactional
    public void seed() {
        seedUsers();
        seedProjects();
        seedExpenses();
    }

    // ----------------------------------------------------------------
    // USERS
    // ----------------------------------------------------------------
    private void seedUsers() {
        if (userRepository.count() > 0) return;

        userRepository.saveAll(List.of(
            User.builder()
                .email("admin@sda.com")
                .password(passwordEncoder.encode("admin123"))
                .name("Admin User")
                .role(User.Role.ADMIN)
                .build(),
            User.builder()
                .email("engineer@sda.com")
                .password(passwordEncoder.encode("eng123"))
                .name("John Engineer")
                .role(User.Role.ENGINEER)
                .build(),
            User.builder()
                .email("accountant@sda.com")
                .password(passwordEncoder.encode("acc123"))
                .name("Sarah Accountant")
                .role(User.Role.ACCOUNTANT)
                .build(),
            User.builder()
                .email("leader@sda.com")
                .password(passwordEncoder.encode("leader123"))
                .name("David Leader")
                .role(User.Role.LEADER)
                .build()
        ));
    }

    // ----------------------------------------------------------------
    // PROJECTS  (8 realistic construction projects)
    // ----------------------------------------------------------------
    private void seedProjects() {
        if (projectRepository.count() > 0) return;

        projectRepository.saveAll(List.of(
            Project.builder()
                .projectCode("PRJ-2024-001")
                .name("Bridge Construction")
                .location("Downtown")
                .manager("John Smith")
                .status(Project.Status.ACTIVE)
                .budget(new BigDecimal("450000"))
                .progress(65)
                .build(),
            Project.builder()
                .projectCode("PRJ-2024-002")
                .name("Road Rehabilitation")
                .location("Highway 101")
                .manager("Mary Johnson")
                .status(Project.Status.PENDING)
                .budget(new BigDecimal("320000"))
                .progress(0)
                .build(),
            Project.builder()
                .projectCode("PRJ-2024-003")
                .name("School Building")
                .location("North District")
                .manager("David Wilson")
                .status(Project.Status.COMPLETED)
                .budget(new BigDecimal("680000"))
                .progress(100)
                .build(),
            Project.builder()
                .projectCode("PRJ-2024-004")
                .name("Water Infrastructure")
                .location("East Side")
                .manager("Sarah Brown")
                .status(Project.Status.ACTIVE)
                .budget(new BigDecimal("520000"))
                .progress(45)
                .build(),
            Project.builder()
                .projectCode("PRJ-2024-005")
                .name("Community Health Centre")
                .location("West End")
                .manager("James Mugisha")
                .status(Project.Status.ACTIVE)
                .budget(new BigDecimal("750000"))
                .progress(30)
                .build(),
            Project.builder()
                .projectCode("PRJ-2024-006")
                .name("Solar Power Installation")
                .location("Industrial Zone")
                .manager("Grace Uwimana")
                .status(Project.Status.PENDING)
                .budget(new BigDecimal("290000"))
                .progress(0)
                .build(),
            Project.builder()
                .projectCode("PRJ-2024-007")
                .name("Market Renovation")
                .location("City Centre")
                .manager("Peter Nkurunziza")
                .status(Project.Status.COMPLETED)
                .budget(new BigDecimal("185000"))
                .progress(100)
                .build(),
            Project.builder()
                .projectCode("PRJ-2024-008")
                .name("Airport Terminal Expansion")
                .location("Kigali International")
                .manager("Alice Mutoni")
                .status(Project.Status.ACTIVE)
                .budget(new BigDecimal("2400000"))
                .progress(20)
                .build()
        ));
    }

    // ----------------------------------------------------------------
    // EXPENSES  (realistic spread across all projects)
    // ----------------------------------------------------------------
    private void seedExpenses() {
        if (expenseRepository.count() > 0) return;

        Project p1 = projectRepository.findByProjectCode("PRJ-2024-001").orElseThrow();
        Project p2 = projectRepository.findByProjectCode("PRJ-2024-002").orElseThrow();
        Project p3 = projectRepository.findByProjectCode("PRJ-2024-003").orElseThrow();
        Project p4 = projectRepository.findByProjectCode("PRJ-2024-004").orElseThrow();
        Project p5 = projectRepository.findByProjectCode("PRJ-2024-005").orElseThrow();
        Project p6 = projectRepository.findByProjectCode("PRJ-2024-006").orElseThrow();
        Project p7 = projectRepository.findByProjectCode("PRJ-2024-007").orElseThrow();
        Project p8 = projectRepository.findByProjectCode("PRJ-2024-008").orElseThrow();

        expenseRepository.saveAll(List.of(

            // --- PRJ-2024-001  Bridge Construction ---
            Expense.builder().expenseCode("EXP-001").project(p1)
                .category(Expense.Category.MATERIALS).amount(new BigDecimal("135000"))
                .expenseDate(LocalDate.of(2024, 1, 15)).vendor("BuildMart Ltd").build(),
            Expense.builder().expenseCode("EXP-002").project(p1)
                .category(Expense.Category.LABOR).amount(new BigDecimal("98000"))
                .expenseDate(LocalDate.of(2024, 2, 3)).vendor("Labor Force Inc").build(),
            Expense.builder().expenseCode("EXP-003").project(p1)
                .category(Expense.Category.EQUIPMENT).amount(new BigDecimal("42000"))
                .expenseDate(LocalDate.of(2024, 2, 18)).vendor("HeavyRent Co").build(),
            Expense.builder().expenseCode("EXP-004").project(p1)
                .category(Expense.Category.TRANSPORT).amount(new BigDecimal("12500"))
                .expenseDate(LocalDate.of(2024, 3, 5)).vendor("FastHaul Logistics").build(),

            // --- PRJ-2024-002  Road Rehabilitation ---
            Expense.builder().expenseCode("EXP-005").project(p2)
                .category(Expense.Category.MATERIALS).amount(new BigDecimal("54000"))
                .expenseDate(LocalDate.of(2024, 1, 22)).vendor("RoadSupply Co").build(),
            Expense.builder().expenseCode("EXP-006").project(p2)
                .category(Expense.Category.EQUIPMENT).amount(new BigDecimal("48000"))
                .expenseDate(LocalDate.of(2024, 2, 10)).vendor("Rental Pro").build(),

            // --- PRJ-2024-003  School Building ---
            Expense.builder().expenseCode("EXP-007").project(p3)
                .category(Expense.Category.MATERIALS).amount(new BigDecimal("220000"))
                .expenseDate(LocalDate.of(2024, 1, 10)).vendor("BuildMart Ltd").build(),
            Expense.builder().expenseCode("EXP-008").project(p3)
                .category(Expense.Category.LABOR).amount(new BigDecimal("175000"))
                .expenseDate(LocalDate.of(2024, 2, 28)).vendor("SkillBuild Contractors").build(),
            Expense.builder().expenseCode("EXP-009").project(p3)
                .category(Expense.Category.OTHER).amount(new BigDecimal("32000"))
                .expenseDate(LocalDate.of(2024, 3, 15)).vendor("Permits & Inspections Office").build(),

            // --- PRJ-2024-004  Water Infrastructure ---
            Expense.builder().expenseCode("EXP-010").project(p4)
                .category(Expense.Category.MATERIALS).amount(new BigDecimal("88000"))
                .expenseDate(LocalDate.of(2024, 2, 5)).vendor("PipeTech Supplies").build(),
            Expense.builder().expenseCode("EXP-011").project(p4)
                .category(Expense.Category.LABOR).amount(new BigDecimal("65000"))
                .expenseDate(LocalDate.of(2024, 3, 1)).vendor("Labor Force Inc").build(),
            Expense.builder().expenseCode("EXP-012").project(p4)
                .category(Expense.Category.EQUIPMENT).amount(new BigDecimal("37500"))
                .expenseDate(LocalDate.of(2024, 3, 20)).vendor("HeavyRent Co").build(),

            // --- PRJ-2024-005  Community Health Centre ---
            Expense.builder().expenseCode("EXP-013").project(p5)
                .category(Expense.Category.MATERIALS).amount(new BigDecimal("112000"))
                .expenseDate(LocalDate.of(2024, 3, 8)).vendor("MedBuild Supplies").build(),
            Expense.builder().expenseCode("EXP-014").project(p5)
                .category(Expense.Category.LABOR).amount(new BigDecimal("95000"))
                .expenseDate(LocalDate.of(2024, 4, 2)).vendor("SkillBuild Contractors").build(),
            Expense.builder().expenseCode("EXP-015").project(p5)
                .category(Expense.Category.TRANSPORT).amount(new BigDecimal("18000"))
                .expenseDate(LocalDate.of(2024, 4, 14)).vendor("FastHaul Logistics").build(),

            // --- PRJ-2024-006  Solar Power Installation ---
            Expense.builder().expenseCode("EXP-016").project(p6)
                .category(Expense.Category.MATERIALS).amount(new BigDecimal("74000"))
                .expenseDate(LocalDate.of(2024, 4, 20)).vendor("SolarTech Rwanda").build(),
            Expense.builder().expenseCode("EXP-017").project(p6)
                .category(Expense.Category.EQUIPMENT).amount(new BigDecimal("28000"))
                .expenseDate(LocalDate.of(2024, 5, 3)).vendor("Rental Pro").build(),

            // --- PRJ-2024-007  Market Renovation ---
            Expense.builder().expenseCode("EXP-018").project(p7)
                .category(Expense.Category.MATERIALS).amount(new BigDecimal("62000"))
                .expenseDate(LocalDate.of(2023, 10, 5)).vendor("BuildMart Ltd").build(),
            Expense.builder().expenseCode("EXP-019").project(p7)
                .category(Expense.Category.LABOR).amount(new BigDecimal("55000"))
                .expenseDate(LocalDate.of(2023, 11, 12)).vendor("Labor Force Inc").build(),
            Expense.builder().expenseCode("EXP-020").project(p7)
                .category(Expense.Category.OTHER).amount(new BigDecimal("14500"))
                .expenseDate(LocalDate.of(2023, 12, 1)).vendor("City Council Fees").build(),

            // --- PRJ-2024-008  Airport Terminal Expansion ---
            Expense.builder().expenseCode("EXP-021").project(p8)
                .category(Expense.Category.MATERIALS).amount(new BigDecimal("380000"))
                .expenseDate(LocalDate.of(2024, 4, 10)).vendor("AeroBuild Supplies").build(),
            Expense.builder().expenseCode("EXP-022").project(p8)
                .category(Expense.Category.LABOR).amount(new BigDecimal("210000"))
                .expenseDate(LocalDate.of(2024, 5, 1)).vendor("SkillBuild Contractors").build(),
            Expense.builder().expenseCode("EXP-023").project(p8)
                .category(Expense.Category.EQUIPMENT).amount(new BigDecimal("145000"))
                .expenseDate(LocalDate.of(2024, 5, 15)).vendor("HeavyRent Co").build(),
            Expense.builder().expenseCode("EXP-024").project(p8)
                .category(Expense.Category.TRANSPORT).amount(new BigDecimal("42000"))
                .expenseDate(LocalDate.of(2024, 6, 1)).vendor("FastHaul Logistics").build()
        ));
    }
}
