package nuyu.com.sdaproject.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import nuyu.com.sdaproject.dto.ApiResponse;
import nuyu.com.sdaproject.dto.ProjectRequest;
import nuyu.com.sdaproject.dto.ProjectResponse;
import nuyu.com.sdaproject.model.Project;
import nuyu.com.sdaproject.service.ProjectService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projects")
@Tag(name = "Projects", description = "Construction project management")
@SecurityRequirement(name = "bearerAuth")
public class ProjectController {

    private final ProjectService projectService;

    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }

    @GetMapping
    @Operation(summary = "Get all projects", description = "Returns all projects. Optionally filter by status or search by keyword.")
    public ResponseEntity<ApiResponse<List<ProjectResponse>>> getAllProjects(
            @Parameter(description = "Filter by status: ACTIVE, PENDING, COMPLETED")
            @RequestParam(required = false) Project.Status status,
            @Parameter(description = "Search by name, location, or manager")
            @RequestParam(required = false) String search) {

        List<ProjectResponse> projects;
        if (status != null) {
            projects = projectService.getByStatus(status);
        } else if (search != null && !search.isBlank()) {
            projects = projectService.searchProjects(search);
        } else {
            projects = projectService.getAllProjects();
        }
        return ResponseEntity.ok(ApiResponse.success("Projects retrieved", projects));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get project by ID")
    public ResponseEntity<ApiResponse<ProjectResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Project retrieved", projectService.getById(id)));
    }

    @GetMapping("/code/{projectCode}")
    @Operation(summary = "Get project by project code (e.g. PRJ-2024-001)")
    public ResponseEntity<ApiResponse<ProjectResponse>> getByCode(@PathVariable String projectCode) {
        return ResponseEntity.ok(ApiResponse.success("Project retrieved", projectService.getByCode(projectCode)));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Create a new project", description = "Admin only.")
    public ResponseEntity<ApiResponse<ProjectResponse>> createProject(@Valid @RequestBody ProjectRequest request) {
        ProjectResponse created = projectService.createProject(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Project created successfully", created));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Update a project", description = "Admin only.")
    public ResponseEntity<ApiResponse<ProjectResponse>> updateProject(
            @PathVariable Long id, @Valid @RequestBody ProjectRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Project updated successfully",
                projectService.updateProject(id, request)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete a project", description = "Admin only. Also deletes all associated expenses.")
    public ResponseEntity<ApiResponse<Void>> deleteProject(@PathVariable Long id) {
        projectService.deleteProject(id);
        return ResponseEntity.ok(ApiResponse.success("Project deleted successfully", null));
    }
}
