package nuyu.com.sdaproject.dto;

import lombok.Builder;
import lombok.Data;
import nuyu.com.sdaproject.model.Expense;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @Builder
public class ExpenseResponse {
    private Long id;
    private String expenseCode;
    private String projectCode;
    private String projectName;
    private Expense.Category category;
    private BigDecimal amount;
    private LocalDate expenseDate;
    private String vendor;
    private LocalDateTime createdAt;
}
