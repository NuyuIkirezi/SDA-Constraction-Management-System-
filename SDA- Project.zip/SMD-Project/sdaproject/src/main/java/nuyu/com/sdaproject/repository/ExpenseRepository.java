package nuyu.com.sdaproject.repository;

import nuyu.com.sdaproject.model.Expense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {

    Optional<Expense> findByExpenseCode(String expenseCode);

    boolean existsByExpenseCode(String expenseCode);

    List<Expense> findByProjectId(Long projectId);

    List<Expense> findByProjectProjectCode(String projectCode);

    List<Expense> findByCategory(Expense.Category category);

    @Query("SELECT SUM(e.amount) FROM Expense e")
    BigDecimal sumTotalExpenses();

    @Query("SELECT SUM(e.amount) FROM Expense e WHERE e.project.id = :projectId")
    BigDecimal sumExpensesByProject(@Param("projectId") Long projectId);

    @Query("SELECT e.category, SUM(e.amount) FROM Expense e GROUP BY e.category")
    List<Object[]> sumExpensesByCategory();

    @Query("SELECT e FROM Expense e WHERE e.project.id = :projectId ORDER BY e.expenseDate DESC")
    List<Expense> findByProjectIdOrderByDateDesc(@Param("projectId") Long projectId);
}
