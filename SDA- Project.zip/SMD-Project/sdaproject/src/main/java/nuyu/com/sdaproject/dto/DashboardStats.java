package nuyu.com.sdaproject.dto;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Map;

@Data @Builder
public class DashboardStats {
    private long totalProjects;
    private long activeProjects;
    private long pendingProjects;
    private long completedProjects;
    private BigDecimal totalBudget;
    private BigDecimal totalExpenses;
    private BigDecimal remainingBudget;
    private double budgetUtilizationPercent;
    private double averageProgress;
    private Map<String, BigDecimal> expensesByCategory;
}
