package nuyu.com.sdaproject.service;

import nuyu.com.sdaproject.dto.ProjectRequest;
import nuyu.com.sdaproject.dto.ProjectResponse;
import nuyu.com.sdaproject.exception.ResourceNotFoundException;
import nuyu.com.sdaproject.model.Project;
import nuyu.com.sdaproject.repository.ExpenseRepository;
import nuyu.com.sdaproject.repository.ProjectRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@Transactional
public class ProjectService {

    private final ProjectRepository projectRepository;
    private final ExpenseRepository expenseRepository;

    public ProjectService(ProjectRepository projectRepository, ExpenseRepository expenseRepository) {
        this.projectRepository = projectRepository;
        this.expenseRepository = expenseRepository;
    }

    public List<ProjectResponse> getAllProjects() {
        return projectRepository.findAll().stream().map(this::toResponse).toList();
    }

    public ProjectResponse getByCode(String projectCode) {
        Project project = projectRepository.findByProjectCode(projectCode)
                .orElseThrow(() -> new ResourceNotFoundException("Project not found: " + projectCode));
        return toResponse(project);
    }

    public ProjectResponse getById(Long id) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Project not found with id: " + id));
        return toResponse(project);
    }

    public List<ProjectResponse> getByStatus(Project.Status status) {
        return projectRepository.findByStatus(status).stream().map(this::toResponse).toList();
    }

    public List<ProjectResponse> searchProjects(String keyword) {
        return projectRepository.searchProjects(keyword).stream().map(this::toResponse).toList();
    }

    public ProjectResponse createProject(ProjectRequest request) {
        String code = generateProjectCode();
        Project project = Project.builder()
                .projectCode(code)
                .name(request.getName())
                .location(request.getLocation())
                .manager(request.getManager())
                .budget(request.getBudget())
                .status(request.getStatus())
                .progress(request.getProgress())
                .build();
        return toResponse(projectRepository.save(project));
    }

    public ProjectResponse updateProject(Long id, ProjectRequest request) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Project not found with id: " + id));
        project.setName(request.getName());
        project.setLocation(request.getLocation());
        project.setManager(request.getManager());
        project.setBudget(request.getBudget());
        project.setStatus(request.getStatus());
        project.setProgress(request.getProgress());
        return toResponse(projectRepository.save(project));
    }

    public void deleteProject(Long id) {
        if (!projectRepository.existsById(id)) {
            throw new ResourceNotFoundException("Project not found with id: " + id);
        }
        projectRepository.deleteById(id);
    }

    private String generateProjectCode() {
        long count = projectRepository.count() + 1;
        return String.format("PRJ-%d-%03d", java.time.Year.now().getValue(), count);
    }

    private ProjectResponse toResponse(Project project) {
        BigDecimal totalExpenses = expenseRepository.sumExpensesByProject(project.getId());
        return ProjectResponse.builder()
                .id(project.getId())
                .projectCode(project.getProjectCode())
                .name(project.getName())
                .location(project.getLocation())
                .manager(project.getManager())
                .status(project.getStatus())
                .budget(project.getBudget())
                .progress(project.getProgress())
                .totalExpenses(totalExpenses != null ? totalExpenses : BigDecimal.ZERO)
                .createdAt(project.getCreatedAt())
                .updatedAt(project.getUpdatedAt())
                .build();
    }

}
