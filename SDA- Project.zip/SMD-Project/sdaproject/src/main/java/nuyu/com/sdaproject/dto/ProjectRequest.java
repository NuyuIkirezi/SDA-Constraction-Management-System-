package nuyu.com.sdaproject.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import nuyu.com.sdaproject.model.Project;

import java.math.BigDecimal;

@Data
public class ProjectRequest {

    @NotBlank(message = "Project name is required")
    private String name;

    @NotBlank(message = "Location is required")
    private String location;

    @NotBlank(message = "Manager name is required")
    private String manager;

    @NotNull(message = "Budget is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Budget must be greater than 0")
    private BigDecimal budget;

    @NotNull(message = "Status is required")
    private Project.Status status;

    @Min(value = 0, message = "Progress cannot be negative")
    @Max(value = 100, message = "Progress cannot exceed 100")
    private Integer progress = 0;
}
