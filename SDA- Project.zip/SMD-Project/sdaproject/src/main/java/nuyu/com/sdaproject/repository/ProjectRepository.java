package nuyu.com.sdaproject.repository;

import nuyu.com.sdaproject.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {

    Optional<Project> findByProjectCode(String projectCode);

    boolean existsByProjectCode(String projectCode);

    List<Project> findByStatus(Project.Status status);

    List<Project> findByManagerContainingIgnoreCase(String manager);

    @Query("SELECT p FROM Project p WHERE LOWER(p.name) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(p.location) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(p.manager) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Project> searchProjects(@Param("keyword") String keyword);

    @Query("SELECT COUNT(p) FROM Project p WHERE p.status = :status")
    long countByStatus(@Param("status") Project.Status status);

    @Query("SELECT SUM(p.budget) FROM Project p")
    java.math.BigDecimal sumTotalBudget();

    @Query("SELECT AVG(p.progress) FROM Project p")
    Double averageProgress();
}
