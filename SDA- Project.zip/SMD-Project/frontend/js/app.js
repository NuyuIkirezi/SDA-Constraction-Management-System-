/* ============================================================
   APP.JS — API Client, Auth, State, Navigation, Helpers
   ============================================================ */

const API_BASE = 'http://localhost:8081/api';

// --- In-memory state (populated from API) ---
let projects    = [];
let expenses    = [];
let currentUser = null;
let currentSection = 'dashboard';

// ============================================================
// API CLIENT
// ============================================================

function getToken() {
    return localStorage.getItem('sda_token');
}

function saveSession(authData) {
    localStorage.setItem('sda_token', authData.token);
    localStorage.setItem('sda_user', JSON.stringify({
        id:    authData.id,
        name:  authData.name,
        email: authData.email,
        role:  authData.role.toLowerCase()   // normalize to lowercase for UI checks
    }));
}

function clearSession() {
    localStorage.removeItem('sda_token');
    localStorage.removeItem('sda_user');
}

function loadSession() {
    const raw = localStorage.getItem('sda_user');
    return raw ? JSON.parse(raw) : null;
}

/**
 * Central fetch wrapper — attaches JWT, handles 401, parses ApiResponse<T>
 */
async function api(method, path, body = null) {
    const headers = { 'Content-Type': 'application/json' };
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const options = { method, headers };
    if (body) options.body = JSON.stringify(body);

    const res = await fetch(`${API_BASE}${path}`, options);

    if (res.status === 401) {
        clearSession();
        showLoginPage();
        showNotification('Session expired. Please log in again.', 'error');
        throw new Error('Unauthorized');
    }

    const json = await res.json();

    if (!res.ok || !json.success) {
        // Validation errors come back as data object
        const msg = typeof json.data === 'object' && json.data !== null
            ? Object.values(json.data).join(', ')
            : json.message || 'An error occurred';
        throw new Error(msg);
    }

    return json.data;
}

// ============================================================
// NOTIFICATION
// ============================================================

let notifTimer = null;

function showNotification(message, type = 'success') {
    const el   = document.getElementById('notification');
    const msg  = document.getElementById('notificationMessage');
    const icon = el.querySelector('i');

    const icons = {
        success: 'fa-check-circle',
        error:   'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle'
    };
    icon.className  = `fas ${icons[type] || icons.success}`;
    msg.textContent = message;
    el.className    = `notification show ${type}`;

    clearTimeout(notifTimer);
    notifTimer = setTimeout(() => el.classList.remove('show'), 3500);
}

// ============================================================
// CUSTOM CONFIRM DIALOG
// ============================================================

function showConfirm(message, onConfirm) {
    const overlay = document.getElementById('confirmOverlay');
    document.getElementById('confirmMessage').textContent = message;
    overlay.classList.add('show');

    // Replace buttons to remove old listeners
    ['confirmOkBtn', 'confirmCancelBtn'].forEach(id => {
        const old = document.getElementById(id);
        const clone = old.cloneNode(true);
        old.replaceWith(clone);
    });

    const cleanup = () => overlay.classList.remove('show');
    document.getElementById('confirmOkBtn').addEventListener('click', () => { cleanup(); onConfirm(); });
    document.getElementById('confirmCancelBtn').addEventListener('click', cleanup);
}

// ============================================================
// AUTH
// ============================================================

async function handleLogin(e) {
    e.preventDefault();

    const email    = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const errorEl  = document.getElementById('loginError');
    const submitBtn = document.querySelector('#loginForm button[type="submit"]');

    errorEl.classList.remove('show');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing in...';

    try {
        const data = await api('POST', '/auth/login', { email, password });

        saveSession(data);
        currentUser = loadSession();

        errorEl.classList.remove('show');
        showDashboardPage();
        navigateTo('dashboard');
        showNotification(`Welcome back, ${currentUser.name}!`);

    } catch (err) {
        errorEl.classList.add('show');
        document.getElementById('loginError').querySelector('span').textContent =
            err.message.includes('Unauthorized') || err.message.includes('Invalid')
                ? 'Invalid email or password. Please try again.'
                : err.message;
        document.getElementById('password').value = '';
        document.getElementById('password').focus();
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Sign In';
    }
}

function handleLogout() {
    clearSession();
    currentUser = null;
    projects    = [];
    expenses    = [];
    showLoginPage();
    showNotification('Logged out successfully');
}

function showLoginPage() {
    document.getElementById('dashboardPage').classList.remove('show');
    document.getElementById('loginPage').style.display = 'flex';
    document.getElementById('loginForm').reset();
    document.getElementById('loginError').classList.remove('show');
}

function showDashboardPage() {
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('dashboardPage').classList.add('show');

    const initials = currentUser.name.split(' ').map(n => n[0]).join('').substring(0, 2);
    const roleLabel = currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1);

    // Sidebar footer
    document.getElementById('displayName').textContent  = currentUser.name;
    document.getElementById('displayRole').textContent  = roleLabel;
    document.getElementById('userAvatar').textContent   = initials;

    // Header user chip
    document.getElementById('headerName').textContent   = currentUser.name;
    document.getElementById('headerRole').textContent   = roleLabel;
    document.getElementById('headerAvatar').textContent = initials;
}

// ============================================================
// NAVIGATION
// ============================================================

function navigateTo(section) {
    currentSection = section;

    document.querySelectorAll('.nav-item').forEach(item =>
        item.classList.toggle('active', item.dataset.section === section)
    );

    // Update header breadcrumb
    const labels = {
        dashboard: 'Dashboard',
        projects:  'Projects',
        budget:    'Budget',
        expenses:  'Expenses',
        reports:   'Reports'
    };
    const headerSection = document.getElementById('headerSection');
    if (headerSection) headerSection.textContent = labels[section] || section;

    const content = document.getElementById('dashboardContent');
    content.innerHTML = `<div class="loading-state"><div class="spinner"></div></div>`;
    content.scrollTop = 0;
    const mainWrapper = document.querySelector('.main-wrapper');
    if (mainWrapper) mainWrapper.scrollTop = 0;

    loadSection(section);
}

// ============================================================
// PASSWORD TOGGLE
// ============================================================

function togglePassword() {
    const input = document.getElementById('password');
    const icon  = document.querySelector('.toggle-password i');
    if (input.type === 'password') {
        input.type    = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type    = 'password';
        icon.className = 'fas fa-eye';
    }
}

// ============================================================
// HELPERS
// ============================================================

/** Normalize backend UPPERCASE status to lowercase for CSS classes */
function normalizeStatus(status) {
    return (status || '').toLowerCase();
}

/** Normalize backend UPPERCASE category to Title Case for display */
function formatCategory(cat) {
    if (!cat) return '';
    return cat.charAt(0).toUpperCase() + cat.slice(1).toLowerCase();
}

function progressBarHTML(value) {
    const pct = Math.min(100, Math.max(0, Number(value) || 0));
    const cls = pct < 40 ? 'warning' : '';
    return `
        <div class="progress-cell">
            <div class="progress-bar-wrap">
                <div class="progress-bar-fill ${cls}" style="width:${pct}%"></div>
            </div>
            <div class="progress-label">${pct}%</div>
        </div>`;
}

function canWrite() {
    return currentUser?.role === 'admin';
}

function canWriteExpense() {
    return currentUser?.role === 'admin' || currentUser?.role === 'accountant';
}

function emptyState(icon, message) {
    return `<div class="empty-state"><i class="fas ${icon}"></i><p>${message}</p></div>`;
}

function formatCurrency(value) {
    return `$${Number(value || 0).toLocaleString()}`;
}

// ============================================================
// INIT
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    // Restore session if token exists
    const savedUser = loadSession();
    if (savedUser && getToken()) {
        currentUser = savedUser;
        showDashboardPage();
        navigateTo('dashboard');
    }

    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);

    document.querySelectorAll('.nav-item').forEach(item =>
        item.addEventListener('click', () => navigateTo(item.dataset.section))
    );

    // Sidebar toggle (collapse on desktop, slide on mobile)
    const sidebar   = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('sidebarToggle');

    // Inject backdrop for mobile
    const backdrop = document.createElement('div');
    backdrop.className = 'sidebar-backdrop';
    document.body.appendChild(backdrop);

    toggleBtn?.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
            sidebar.classList.toggle('mobile-open');
            backdrop.classList.toggle('show');
        } else {
            sidebar.classList.toggle('collapsed');
        }
    });

    backdrop.addEventListener('click', () => {
        sidebar.classList.remove('mobile-open');
        backdrop.classList.remove('show');
    });

    // Notification bell toggle
    const notifBtn      = document.getElementById('notifBtn');
    const notifDropdown = document.getElementById('notifDropdown');
    const notifClear    = document.getElementById('notifClear');

    notifBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = notifDropdown.classList.toggle('open');
        notifBtn.setAttribute('aria-expanded', isOpen);
        if (isOpen) {
            // Mark all as read visually
            document.querySelectorAll('.notif-item.unread').forEach(el => el.classList.remove('unread'));
            document.getElementById('notifBadge').textContent = '';
        }
    });

    notifClear?.addEventListener('click', () => {
        document.getElementById('notifList').innerHTML =
            '<div class="notif-empty"><i class="fas fa-bell-slash" style="margin-right:0.4rem"></i>No notifications</div>';
        document.getElementById('notifBadge').textContent = '';
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('#notifBell')) {
            notifDropdown?.classList.remove('open');
            notifBtn?.setAttribute('aria-expanded', 'false');
        }
    });

    // Escape closes modals, confirm dialog, and notification dropdown
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal.show').forEach(m => m.remove());
            document.getElementById('confirmOverlay')?.classList.remove('show');
            notifDropdown?.classList.remove('open');
        }
    });
});
