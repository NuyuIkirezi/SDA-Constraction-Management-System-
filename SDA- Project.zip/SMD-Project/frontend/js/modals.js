/* ============================================================
   MODALS.JS — CRUD Modals wired to real backend API
   ============================================================ */

// ============================================================
// MODAL FACTORY
// ============================================================

function createModal(titleText, bodyHTML) {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>${titleText}</h3>
                <button class="close-modal" aria-label="Close">&times;</button>
            </div>
            <div class="modal-body">${bodyHTML}</div>
        </div>`;

    modal.querySelector('.close-modal').addEventListener('click', () => modal.remove());
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
    document.body.appendChild(modal);
    return modal;
}

function setModalLoading(btn, loading) {
    btn.disabled = loading;
    btn.innerHTML = loading
        ? '<i class="fas fa-spinner fa-spin"></i> Saving...'
        : btn.dataset.label;
}

// ============================================================
// PROJECT FORM TEMPLATE
// ============================================================

function projectFormHTML(p = {}) {
    // Backend sends status as ACTIVE/PENDING/COMPLETED — normalize for comparison
    const status = (p.status || '').toUpperCase();
    return `
        <div class="form-group">
            <label class="form-label" for="projectName">Project Name</label>
            <input type="text" class="form-input" id="projectName"
                   value="${p.name || ''}" placeholder="e.g. Bridge Construction" required>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label" for="projectLocation">Location</label>
                <input type="text" class="form-input" id="projectLocation"
                       value="${p.location || ''}" placeholder="e.g. Downtown" required>
            </div>
            <div class="form-group">
                <label class="form-label" for="projectManager">Manager</label>
                <input type="text" class="form-input" id="projectManager"
                       value="${p.manager || ''}" placeholder="Full name" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label" for="projectBudget">Budget ($)</label>
                <input type="number" class="form-input" id="projectBudget"
                       value="${p.budget || ''}" placeholder="e.g. 450000" min="1" required>
            </div>
            <div class="form-group">
                <label class="form-label" for="projectStatus">Status</label>
                <select class="form-select" id="projectStatus" required>
                    <option value="ACTIVE"    ${status === 'ACTIVE'    ? 'selected' : ''}>Active</option>
                    <option value="PENDING"   ${status === 'PENDING'   ? 'selected' : ''}>Pending</option>
                    <option value="COMPLETED" ${status === 'COMPLETED' ? 'selected' : ''}>Completed</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label class="form-label" for="projectProgress">
                Progress (<span id="progressVal">${p.progress ?? 0}</span>%)
            </label>
            <input type="range" id="projectProgress" min="0" max="100"
                   value="${p.progress ?? 0}"
                   style="width:100%;accent-color:var(--primary-teal);"
                   oninput="document.getElementById('progressVal').textContent = this.value">
        </div>`;
}

// ============================================================
// EXPENSE FORM TEMPLATE
// ============================================================

function expenseFormHTML(e = {}) {
    // projects cache must be loaded — if empty, fetch inline
    const projectOptions = projects.map(p =>
        `<option value="${p.projectCode}" ${e.projectCode === p.projectCode ? 'selected' : ''}>
            ${p.name} (${p.projectCode})
         </option>`
    ).join('');

    const cats = ['MATERIALS', 'LABOR', 'EQUIPMENT', 'TRANSPORT', 'OTHER'];
    const catOptions = cats.map(c =>
        `<option value="${c}" ${(e.category || '').toUpperCase() === c ? 'selected' : ''}>
            ${formatCategory(c)}
         </option>`
    ).join('');

    return `
        <div class="form-group">
            <label class="form-label" for="expenseProject">Project</label>
            <select class="form-select" id="expenseProject" required>${projectOptions}</select>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label" for="expenseCategory">Category</label>
                <select class="form-select" id="expenseCategory" required>${catOptions}</select>
            </div>
            <div class="form-group">
                <label class="form-label" for="expenseAmount">Amount ($)</label>
                <input type="number" class="form-input" id="expenseAmount"
                       value="${e.amount || ''}" placeholder="e.g. 50000" min="1" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label" for="expenseDate">Date</label>
                <input type="date" class="form-input" id="expenseDate"
                       value="${e.expenseDate || ''}" required>
            </div>
            <div class="form-group">
                <label class="form-label" for="expenseVendor">Vendor</label>
                <input type="text" class="form-input" id="expenseVendor"
                       value="${e.vendor || ''}" placeholder="Vendor name" required>
            </div>
        </div>`;
}

// ============================================================
// PROJECT — ADD
// ============================================================

async function openAddProjectModal() {
    // Ensure projects cache is loaded for expense form
    if (!projects.length) projects = await api('GET', '/projects');

    const modal = createModal('Add New Project', `
        <form id="projectForm">
            ${projectFormHTML()}
            <button type="submit" class="btn btn-primary btn-block" style="margin-top:0.5rem"
                    data-label='<i class="fas fa-plus"></i> Add Project'>
                <i class="fas fa-plus"></i> Add Project
            </button>
        </form>`);

    modal.querySelector('#projectForm').addEventListener('submit', async e => {
        e.preventDefault();
        const btn = modal.querySelector('button[type="submit"]');
        setModalLoading(btn, true);
        try {
            await api('POST', '/projects', {
                name:     document.getElementById('projectName').value.trim(),
                location: document.getElementById('projectLocation').value.trim(),
                manager:  document.getElementById('projectManager').value.trim(),
                budget:   parseFloat(document.getElementById('projectBudget').value),
                status:   document.getElementById('projectStatus').value,
                progress: parseInt(document.getElementById('projectProgress').value)
            });
            modal.remove();
            await navigateTo('projects');
            showNotification('Project added successfully!');
        } catch (err) {
            showNotification(err.message, 'error');
            setModalLoading(btn, false);
        }
    });
}

// ============================================================
// PROJECT — EDIT
// ============================================================

async function openEditProjectModal(projectId) {
    let project;
    try {
        project = await api('GET', `/projects/${projectId}`);
    } catch (err) {
        showNotification(err.message, 'error');
        return;
    }

    const modal = createModal(`Edit — ${project.projectCode}`, `
        <form id="projectForm">
            ${projectFormHTML(project)}
            <button type="submit" class="btn btn-primary btn-block" style="margin-top:0.5rem"
                    data-label='<i class="fas fa-save"></i> Save Changes'>
                <i class="fas fa-save"></i> Save Changes
            </button>
        </form>`);

    modal.querySelector('#projectForm').addEventListener('submit', async e => {
        e.preventDefault();
        const btn = modal.querySelector('button[type="submit"]');
        setModalLoading(btn, true);
        try {
            await api('PUT', `/projects/${projectId}`, {
                name:     document.getElementById('projectName').value.trim(),
                location: document.getElementById('projectLocation').value.trim(),
                manager:  document.getElementById('projectManager').value.trim(),
                budget:   parseFloat(document.getElementById('projectBudget').value),
                status:   document.getElementById('projectStatus').value,
                progress: parseInt(document.getElementById('projectProgress').value)
            });
            modal.remove();
            await navigateTo(currentSection);
            showNotification('Project updated successfully!');
        } catch (err) {
            showNotification(err.message, 'error');
            setModalLoading(btn, false);
        }
    });
}

// ============================================================
// PROJECT — VIEW
// ============================================================

async function viewProject(projectId) {
    let project, projectExpenses;
    try {
        [project, projectExpenses] = await Promise.all([
            api('GET', `/projects/${projectId}`),
            api('GET', `/expenses?projectCode=${encodeURIComponent(
                projects.find(p => p.id === projectId)?.projectCode || ''
            )}`)
        ]);
    } catch (err) {
        showNotification(err.message, 'error');
        return;
    }

    const status = normalizeStatus(project.status);
    const expenseRows = projectExpenses.length
        ? projectExpenses.map(e => `
            <tr>
                <td>${formatCategory(e.category)}</td>
                <td style="font-weight:600;">${formatCurrency(e.amount)}</td>
                <td>${e.expenseDate}</td>
                <td>${e.vendor}</td>
            </tr>`).join('')
        : `<tr><td colspan="4">${emptyState('fa-file-invoice', 'No expenses for this project')}</td></tr>`;

    createModal(`Project — ${project.projectCode}`, `
        <div class="detail-grid">
            <div class="detail-item"><label>Project Name</label><span>${project.name}</span></div>
            <div class="detail-item"><label>Location</label><span>${project.location}</span></div>
            <div class="detail-item"><label>Manager</label><span>${project.manager}</span></div>
            <div class="detail-item"><label>Status</label>
                <span class="status-badge status-${status}">${status}</span>
            </div>
            <div class="detail-item"><label>Budget</label><span>${formatCurrency(project.budget)}</span></div>
            <div class="detail-item"><label>Total Spent</label>
                <span style="color:var(--primary-teal);font-weight:700;">
                    ${formatCurrency(project.totalExpenses)}
                </span>
            </div>
        </div>
        <div style="margin-bottom:1.25rem">${progressBarHTML(project.progress)}</div>
        <h4 style="font-family:'Lora',serif;margin-bottom:0.75rem;font-size:1rem;">Project Expenses</h4>
        <div class="table-wrapper">
            <table class="data-table">
                <thead><tr><th>Category</th><th>Amount</th><th>Date</th><th>Vendor</th></tr></thead>
                <tbody>${expenseRows}</tbody>
            </table>
        </div>`);
}

// ============================================================
// PROJECT — DELETE
// ============================================================

function confirmDeleteProject(projectId, projectName) {
    showConfirm(`Delete "${projectName}"? All linked expenses will also be removed.`, async () => {
        try {
            await api('DELETE', `/projects/${projectId}`);
            await navigateTo(currentSection);
            showNotification('Project deleted successfully!');
        } catch (err) {
            showNotification(err.message, 'error');
        }
    });
}

// ============================================================
// EXPENSE — ADD
// ============================================================

async function openAddExpenseModal() {
    if (!projects.length) projects = await api('GET', '/projects');

    const modal = createModal('Record New Expense', `
        <form id="expenseForm">
            ${expenseFormHTML()}
            <button type="submit" class="btn btn-primary btn-block" style="margin-top:0.5rem"
                    data-label='<i class="fas fa-plus"></i> Record Expense'>
                <i class="fas fa-plus"></i> Record Expense
            </button>
        </form>`);

    modal.querySelector('#expenseForm').addEventListener('submit', async e => {
        e.preventDefault();
        const btn = modal.querySelector('button[type="submit"]');
        setModalLoading(btn, true);
        try {
            await api('POST', '/expenses', {
                projectCode:  document.getElementById('expenseProject').value,
                category:     document.getElementById('expenseCategory').value,
                amount:       parseFloat(document.getElementById('expenseAmount').value),
                expenseDate:  document.getElementById('expenseDate').value,
                vendor:       document.getElementById('expenseVendor').value.trim()
            });
            modal.remove();
            await navigateTo('expenses');
            showNotification('Expense recorded successfully!');
        } catch (err) {
            showNotification(err.message, 'error');
            setModalLoading(btn, false);
        }
    });
}

// ============================================================
// EXPENSE — EDIT
// ============================================================

async function openEditExpenseModal(expenseId) {
    let expense;
    try {
        [expense] = await Promise.all([
            api('GET', `/expenses/${expenseId}`),
            projects.length ? Promise.resolve() : api('GET', '/projects').then(p => { projects = p; })
        ]);
    } catch (err) {
        showNotification(err.message, 'error');
        return;
    }

    const modal = createModal(`Edit — ${expense.expenseCode}`, `
        <form id="expenseForm">
            ${expenseFormHTML(expense)}
            <button type="submit" class="btn btn-primary btn-block" style="margin-top:0.5rem"
                    data-label='<i class="fas fa-save"></i> Save Changes'>
                <i class="fas fa-save"></i> Save Changes
            </button>
        </form>`);

    modal.querySelector('#expenseForm').addEventListener('submit', async e => {
        e.preventDefault();
        const btn = modal.querySelector('button[type="submit"]');
        setModalLoading(btn, true);
        try {
            await api('PUT', `/expenses/${expenseId}`, {
                projectCode:  document.getElementById('expenseProject').value,
                category:     document.getElementById('expenseCategory').value,
                amount:       parseFloat(document.getElementById('expenseAmount').value),
                expenseDate:  document.getElementById('expenseDate').value,
                vendor:       document.getElementById('expenseVendor').value.trim()
            });
            modal.remove();
            await navigateTo(currentSection);
            showNotification('Expense updated successfully!');
        } catch (err) {
            showNotification(err.message, 'error');
            setModalLoading(btn, false);
        }
    });
}

// ============================================================
// EXPENSE — VIEW
// ============================================================

async function viewExpense(expenseId) {
    let expense;
    try {
        expense = await api('GET', `/expenses/${expenseId}`);
    } catch (err) {
        showNotification(err.message, 'error');
        return;
    }

    createModal(`Expense — ${expense.expenseCode}`, `
        <div class="detail-grid">
            <div class="detail-item"><label>Expense ID</label><span>${expense.expenseCode}</span></div>
            <div class="detail-item"><label>Project</label><span>${expense.projectName}</span></div>
            <div class="detail-item"><label>Category</label><span>${formatCategory(expense.category)}</span></div>
            <div class="detail-item"><label>Amount</label>
                <span style="color:var(--primary-teal);font-weight:700;">${formatCurrency(expense.amount)}</span>
            </div>
            <div class="detail-item"><label>Date</label><span>${expense.expenseDate}</span></div>
            <div class="detail-item"><label>Vendor</label><span>${expense.vendor}</span></div>
        </div>`);
}

// ============================================================
// EXPENSE — DELETE
// ============================================================

function confirmDeleteExpense(expenseId, expenseCode) {
    showConfirm(`Delete expense "${expenseCode}"? This action cannot be undone.`, async () => {
        try {
            await api('DELETE', `/expenses/${expenseId}`);
            await navigateTo(currentSection);
            showNotification('Expense deleted successfully!');
        } catch (err) {
            showNotification(err.message, 'error');
        }
    });
}
