/* ============================================================
   SECTIONS.JS — Section Renderers consuming real backend API
   ============================================================ */

async function loadSection(section) {
    try {
        switch (section) {
            case 'dashboard': await renderDashboard(); break;
            case 'projects':  await renderProjects();  break;
            case 'budget':    await renderBudget();    break;
            case 'expenses':  await renderExpenses();  break;
            case 'reports':   await renderReports();   break;
        }
    } catch (err) {
        document.getElementById('dashboardContent').innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
                <p>Failed to load data: ${err.message}</p>
                <button class="btn btn-secondary" style="margin-top:1rem" onclick="navigateTo('${section}')">
                    <i class="fas fa-redo"></i> Retry
                </button>
            </div>`;
    }
}

// ============================================================
// DASHBOARD
// ============================================================

async function renderDashboard() {
    // Fetch stats and recent projects in parallel
    const [stats, allProjects] = await Promise.all([
        api('GET', '/reports/dashboard'),
        api('GET', '/projects')
    ]);

    // Keep local cache in sync
    projects = allProjects;

    const content = document.getElementById('dashboardContent');
    content.innerHTML = `
        <div class="section-header">
            <div class="section-header-text">
                <h2>Welcome, ${currentUser.name}</h2>
                <p>Here's what's happening with your projects today</p>
            </div>
            ${canWrite() ? `<button class="btn btn-primary" onclick="openAddProjectModal()">
                <i class="fas fa-plus"></i> New Project</button>` : ''}
        </div>

        <div class="dashboard-grid">
            <div class="dashboard-card">
                <div class="card-icon"><i class="fas fa-project-diagram"></i></div>
                <div class="card-label">Total Projects</div>
                <div class="card-value">${stats.totalProjects}</div>
                <div class="card-sub">${stats.activeProjects} currently active</div>
            </div>
            <div class="dashboard-card">
                <div class="card-icon"><i class="fas fa-coins"></i></div>
                <div class="card-label">Total Budget</div>
                <div class="card-value">$${(Number(stats.totalBudget) / 1_000_000).toFixed(1)}M</div>
                <div class="card-sub">${formatCurrency(stats.totalBudget)} allocated</div>
            </div>
            <div class="dashboard-card">
                <div class="card-icon"><i class="fas fa-file-invoice-dollar"></i></div>
                <div class="card-label">Total Expenses</div>
                <div class="card-value">$${(Number(stats.totalExpenses) / 1_000_000).toFixed(1)}M</div>
                <div class="card-sub">${stats.budgetUtilizationPercent.toFixed(1)}% of total budget</div>
            </div>
            <div class="dashboard-card">
                <div class="card-icon"><i class="fas fa-tasks"></i></div>
                <div class="card-label">Avg Completion</div>
                <div class="card-value">${Math.round(stats.averageProgress)}%</div>
                <div class="card-sub">Across all projects</div>
            </div>
        </div>

        <div class="section-divider"></div>
        <h3 style="font-family:'Lora',serif;font-size:1.2rem;margin-bottom:1.25rem;color:var(--charcoal);">
            Recent Projects
        </h3>

        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Project ID</th><th>Name</th><th>Manager</th>
                        <th>Status</th><th>Budget</th><th>Progress</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${projects.slice(0, 4).map(p => projectRow(p, false)).join('')}
                </tbody>
            </table>
        </div>`;
}

// ============================================================
// PROJECTS
// ============================================================

async function renderProjects() {
    projects = await api('GET', '/projects');

    const content = document.getElementById('dashboardContent');
    content.innerHTML = `
        <div class="section-header">
            <div class="section-header-text">
                <h2>Projects</h2>
                <p>View and manage all construction projects</p>
            </div>
            ${canWrite() ? `<button class="btn btn-primary" onclick="openAddProjectModal()">
                <i class="fas fa-plus"></i> New Project</button>` : ''}
        </div>

        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Project ID</th><th>Name</th><th>Location</th><th>Manager</th>
                        <th>Status</th><th>Budget</th><th>Progress</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${projects.length
                        ? projects.map(p => projectRow(p, true)).join('')
                        : `<tr><td colspan="8">${emptyState('fa-folder-open', 'No projects found')}</td></tr>`}
                </tbody>
            </table>
        </div>`;
}

function projectRow(p, showLocation = false) {
    const status = normalizeStatus(p.status);
    return `
        <tr>
            <td class="td-primary">${p.projectCode}</td>
            <td class="td-strong">${p.name}</td>
            ${showLocation ? `<td>${p.location}</td>` : ''}
            <td>${p.manager}</td>
            <td><span class="status-badge status-${status}">${status}</span></td>
            <td>${formatCurrency(p.budget)}</td>
            <td>${progressBarHTML(p.progress)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn-icon btn-view" onclick="viewProject(${p.id})">
                        <i class="fas fa-eye"></i> View
                    </button>
                    ${canWrite() ? `
                        <button class="btn-icon btn-edit" onclick="openEditProjectModal(${p.id})">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button class="btn-icon btn-delete" onclick="confirmDeleteProject(${p.id}, '${p.name}')">
                            <i class="fas fa-trash"></i>
                        </button>` : ''}
                </div>
            </td>
        </tr>`;
}

// ============================================================
// BUDGET
// ============================================================

async function renderBudget() {
    [projects, expenses] = await Promise.all([
        api('GET', '/projects'),
        api('GET', '/expenses')
    ]);

    const content = document.getElementById('dashboardContent');
    content.innerHTML = `
        <div class="section-header">
            <div class="section-header-text">
                <h2>Budget Overview</h2>
                <p>Track financial allocations across all projects</p>
            </div>
        </div>

        <div class="dashboard-grid">
            ${projects.map(p => {
                const spent = Number(p.totalExpenses || 0);
                const budget = Number(p.budget || 0);
                const pct = budget > 0 ? ((spent / budget) * 100).toFixed(1) : 0;
                const status = normalizeStatus(p.status);
                return `
                    <div class="budget-card">
                        <div class="card-label">${p.name}</div>
                        <div class="card-value">${formatCurrency(p.budget)}</div>
                        <div class="card-sub">Spent: ${formatCurrency(spent)} (${pct}%)</div>
                        <div style="margin-top:0.75rem">${progressBarHTML(parseFloat(pct))}</div>
                        <div style="margin-top:0.5rem">
                            <span class="status-badge status-${status}">${status}</span>
                        </div>
                    </div>`;
            }).join('')}
        </div>

        <div class="section-divider"></div>
        <h3 style="font-family:'Lora',serif;font-size:1.2rem;margin-bottom:1.25rem;color:var(--charcoal);">
            Budget Breakdown by Expense
        </h3>

        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Project</th><th>Category</th><th>Allocated</th>
                        <th>Spent</th><th>Remaining</th><th>Utilization</th>
                    </tr>
                </thead>
                <tbody>
                    ${expenses.length ? expenses.map(e => {
                        const proj      = projects.find(p => p.projectCode === e.projectCode);
                        const allocated = Number(proj?.budget || 0);
                        const spent     = Number(e.amount || 0);
                        const remaining = allocated - spent;
                        const util      = allocated > 0 ? ((spent / allocated) * 100).toFixed(1) : 0;
                        return `
                            <tr>
                                <td class="td-strong">${e.projectName}</td>
                                <td>${formatCategory(e.category)}</td>
                                <td>${formatCurrency(allocated)}</td>
                                <td>${formatCurrency(spent)}</td>
                                <td style="color:${remaining < 0 ? 'var(--danger)' : 'var(--success)'};font-weight:600;">
                                    ${formatCurrency(remaining)}
                                </td>
                                <td>${progressBarHTML(parseFloat(util))}</td>
                            </tr>`;
                    }).join('')
                    : `<tr><td colspan="6">${emptyState('fa-coins', 'No expense data available')}</td></tr>`}
                </tbody>
            </table>
        </div>`;
}

// ============================================================
// EXPENSES
// ============================================================

async function renderExpenses() {
    expenses = await api('GET', '/expenses');

    const content = document.getElementById('dashboardContent');
    content.innerHTML = `
        <div class="section-header">
            <div class="section-header-text">
                <h2>Expenses</h2>
                <p>Record and track project expenditures</p>
            </div>
            ${canWriteExpense() ? `<button class="btn btn-primary" onclick="openAddExpenseModal()">
                <i class="fas fa-plus"></i> Record Expense</button>` : ''}
        </div>

        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Expense ID</th><th>Project</th><th>Category</th>
                        <th>Amount</th><th>Date</th><th>Vendor</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${expenses.length
                        ? expenses.map(e => expenseRow(e)).join('')
                        : `<tr><td colspan="7">${emptyState('fa-file-invoice', 'No expenses recorded yet')}</td></tr>`}
                </tbody>
            </table>
        </div>`;
}

function expenseRow(e) {
    return `
        <tr>
            <td class="td-primary">${e.expenseCode}</td>
            <td class="td-strong">${e.projectName}</td>
            <td>${formatCategory(e.category)}</td>
            <td style="font-weight:600;">${formatCurrency(e.amount)}</td>
            <td>${e.expenseDate}</td>
            <td>${e.vendor}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn-icon btn-view" onclick="viewExpense(${e.id})">
                        <i class="fas fa-eye"></i> View
                    </button>
                    ${canWriteExpense() ? `
                        <button class="btn-icon btn-edit" onclick="openEditExpenseModal(${e.id})">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button class="btn-icon btn-delete" onclick="confirmDeleteExpense(${e.id}, '${e.expenseCode}')">
                            <i class="fas fa-trash"></i>
                        </button>` : ''}
                </div>
            </td>
        </tr>`;
}

// ============================================================
// REPORTS
// ============================================================

async function renderReports() {
    const stats = await api('GET', '/reports/dashboard');

    const content = document.getElementById('dashboardContent');

    // Build category breakdown rows
    const categoryRows = stats.expensesByCategory && Object.keys(stats.expensesByCategory).length
        ? Object.entries(stats.expensesByCategory).map(([cat, amt]) => `
            <tr>
                <td class="td-strong">${formatCategory(cat)}</td>
                <td style="font-weight:600;">${formatCurrency(amt)}</td>
                <td>${stats.totalExpenses > 0
                    ? ((Number(amt) / Number(stats.totalExpenses)) * 100).toFixed(1) + '%'
                    : '0%'}</td>
            </tr>`).join('')
        : `<tr><td colspan="3">${emptyState('fa-chart-bar', 'No expense data')}</td></tr>`;

    content.innerHTML = `
        <div class="section-header">
            <div class="section-header-text">
                <h2>Reports & Analytics</h2>
                <p>Comprehensive project and financial summaries</p>
            </div>
        </div>

        <div class="dashboard-grid">
            <div class="dashboard-card">
                <div class="card-icon"><i class="fas fa-chart-pie"></i></div>
                <div class="card-label">Total Budget</div>
                <div class="card-value">$${(Number(stats.totalBudget) / 1_000_000).toFixed(1)}M</div>
                <div class="card-sub">Across all projects</div>
            </div>
            <div class="dashboard-card">
                <div class="card-icon"><i class="fas fa-chart-line"></i></div>
                <div class="card-label">Avg Progress</div>
                <div class="card-value">${Math.round(stats.averageProgress)}%</div>
                <div class="card-sub">Project completion average</div>
            </div>
            <div class="dashboard-card">
                <div class="card-icon"><i class="fas fa-chart-bar"></i></div>
                <div class="card-label">Total Expenses</div>
                <div class="card-value">$${(Number(stats.totalExpenses) / 1_000_000).toFixed(1)}M</div>
                <div class="card-sub">${stats.budgetUtilizationPercent.toFixed(1)}% utilization</div>
            </div>
            <div class="dashboard-card">
                <div class="card-icon"><i class="fas fa-clock"></i></div>
                <div class="card-label">Active Projects</div>
                <div class="card-value">${stats.activeProjects}</div>
                <div class="card-sub">Currently in progress</div>
            </div>
        </div>

        <div class="section-divider"></div>
        <h3 style="font-family:'Lora',serif;font-size:1.2rem;margin-bottom:1.25rem;color:var(--charcoal);">
            Expense Breakdown by Category
        </h3>

        <div class="table-wrapper" style="margin-bottom:2rem">
            <table class="data-table">
                <thead>
                    <tr><th>Category</th><th>Total Spent</th><th>Share</th></tr>
                </thead>
                <tbody>${categoryRows}</tbody>
            </table>
        </div>

        <div class="section-divider"></div>
        <h3 style="font-family:'Lora',serif;font-size:1.2rem;margin-bottom:1.25rem;color:var(--charcoal);">
            Project Status Summary
        </h3>

        <div class="dashboard-grid">
            <div class="budget-card">
                <div class="card-label">Active</div>
                <div class="card-value" style="color:var(--success)">${stats.activeProjects}</div>
                <div class="card-sub">In progress</div>
            </div>
            <div class="budget-card">
                <div class="card-label">Pending</div>
                <div class="card-value" style="color:var(--warning)">${stats.pendingProjects}</div>
                <div class="card-sub">Not yet started</div>
            </div>
            <div class="budget-card">
                <div class="card-label">Completed</div>
                <div class="card-value" style="color:var(--soft-blue)">${stats.completedProjects}</div>
                <div class="card-sub">Finished</div>
            </div>
            <div class="budget-card">
                <div class="card-label">Remaining Budget</div>
                <div class="card-value" style="font-size:1.4rem;color:var(--primary-teal)">
                    ${formatCurrency(stats.remainingBudget)}
                </div>
                <div class="card-sub">Unspent allocation</div>
            </div>
        </div>`;
}
